import app from 'firebase/app';
import 'firebase/auth';
import * as firebaseui from 'firebaseui';

const firebaseConfig = {
  apiKey: "AIzaSyB12YYwM_qy8avu35T4TkIzdelYbl1ohxI",
  authDomain: "fkproyect.firebaseapp.com",
  databaseURL: "https://fkproyect.firebaseio.com",
  projectId: "fkproyect",
  storageBucket: "fkproyect.appspot.com",
  messagingSenderId: "409150470383",
  appId: "1:409150470383:web:9b37b231940eb8716ac31a"
};

class Firebase {
  constructor() {
      app.initializeApp(firebaseConfig);
      this.auth = app.auth();
      this.autorization = app.auth;
      this.firebaseui = new firebaseui.auth.AuthUI(app.auth());
  }
}

export default Firebase;
