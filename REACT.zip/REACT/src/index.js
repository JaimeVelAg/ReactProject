//const element = document.createElement('h1')

//element.innerText = 'Hello'

//
//container.appendChild(element)

import React from 'react'
import ReactDOM from 'react-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'jquery/dist/jquery.min.js'
import 'bootstrap/dist/js/bootstrap.min.js'
import $ from 'jquery'
import App from './components/App'
const element = <h1>Hello </h1>
const container = document.getElementById('root')

//$('#title').text('kkkkkk')
ReactDOM.render(
  <div>
    <App />
  </div>
  , container)
