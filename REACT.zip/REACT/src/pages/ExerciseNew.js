import React from 'react'

class ExerciseNew extends React.Component {
    render(){
      return "bien"
    }
}

export default ExerciseNew
