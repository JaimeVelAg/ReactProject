import React from 'react'
import './styles/Normas.css'
import normas from '../server/normas.json'
class Normas extends React.Component {
  state = {
    normas : normas
  }
  render(){
    return(
      <div className="container">
        {
          this.state.normas.map((rule) =>{
            return (
              <div>
                <h3 className="title">{rule.titulo}</h3>
                <p className="a">{rule.texto}</p>
              </div>

            )
          })
        }
      </div>
    )
  }
}

export default Normas
