import React from 'react'
import Card from '../components/Card'
import Welcome from '../components/Welcome'
import './styles/Exercises.css'
import $ from 'jquery'
import { Link } from 'react-router-dom'
import Testimonyslist from '../components/Testimonyslist'

class Exercises extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      data: []
    }
  }

  async componentDidMount(){
    await this.fetchCards()
  }

  fetchCards = async () => {
    let res = await fetch('https://fitnesskingdommx.com/API/public/api/testimonys')
    let data = await res.json()

    this.setState({
      data
    })
  }

  render(){
    return (
      <div>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <Welcome
        name="jaime velag"
      />
          <div className="container marketing">
            <div className="row">
                {
                  this.state.data.map((testimony) =>{
                    return (
                      <Testimonyslist
                          title={testimony.title}
                          description={testimony.description}
                          lugar={testimony.lugar}
                      />
                    )
                  })
                }
          </div>
        </div>

    </div>
    )
  }
}



export default Exercises
