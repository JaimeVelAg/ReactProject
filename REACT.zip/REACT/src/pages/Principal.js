import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import CardPrising from '../components/CardPrising'
import './styles/Principal.css'

class Principal extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      data: []
    }
  }

  async componentDidMount(){
    await this.fetchCards()
  }

  fetchCards = async () => {
    let res = await fetch('https://fitnesskingdommx.com/API/public/api/cards')
    let data = await res.json()

    this.setState({
      data
    })
  }


  render(){
    return(
        <div className="principal-container">
          <h1 className="text-1 text-center">Conoce nuestros planes</h1>
          <h5 className="text-2 text-center">¿Cuál escogerás?</h5>
          <br/>
          <div className="grid-cards text-center">
          {
            this.state.data.map((card) =>{
              return(
                  <CardPrising
                      id={card.id}
                      title={card.title}
                      price={card.price}
                      description={card.description}
                      description2={card.description2}
                      description3={card.description3}
                      description4={card.description4}
                  />
              )
            })
          }
          </div>
          <br/>
        </div>
    )
  }
}

export default Principal
