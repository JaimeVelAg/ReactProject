import React from 'react';
import 'firebaseui/dist/firebaseui.css';
import Firebase from '../server/firebase';
import './styles/Login.css'
import Testimonystable from '../components/Testimonystable'
import { Link } from 'react-router-dom'

class Login extends React.Component {
  state = {
    autenticado : false,
    usuario : "",
    firebase : null
  }

  componentDidMount(){
    const firebase = new Firebase();

    firebase.auth.onAuthStateChanged(authUser => {
      authUser
      ? this.setState({
        autenticado : true,
        usuario: firebase.auth.currentUser.email,
        firebase: firebase
        })
        :firebase.firebaseui.start("#firebaseui-auth-container",{
          signInSuccessUrl : "/",
          credentialHelper: "none",
          callbacks:{
            signInSuccessWithAuthResult : (authResult, redirectUrl) => {
              this.setState({
                autenticado : false,
                usuario : firebase.auth.currentUser.email,
                firebase : firebase
              })
              return false;
            }
          },
          signInOptions:[
            {
              provider : firebase.autorization.EmailAuthProvider.PROVIDER_ID
            }
          ]
        })
    })
  }

  render(){
    return (
      this.state.autenticado
    )
    ? (
      <React.Fragment>
        <div className="caja">
        <h4>Bienvenido {this.state.usuario}</h4>
        <a className="btn btn-danger" href="#" onClick={()=> {this.state.firebase.auth.signOut().then(success=> {
                this.setState({ autenticado:false })
                    })
                 } }>Salir</a>
          <Testimonystable
            usuario = {this.state.usuario}
          />
        </div>
      </React.Fragment>
    )
    : <div id="firebaseui-auth-container">
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <div className="cuadro-informacion">
      <h4 className="text text-center">Inicia sesión o crea una cuenta para ver los comentarios</h4>
      <h6 className="text text-center info">No usamos ningún dato que ingreses, sólo es para llevar un control de usuarios.</h6>
      <h6 className="text text-center info-2">Cualquier comentarrio que inflinja las normas de la comunidad será eliminado y el usuario será bloqueado sin excepcion.</h6>
      <Link className="btn btn-success text-center" to="../normas/">Ver normas</Link>
      </div>
      <br/>
      </div>
  }
}

export default Login;
