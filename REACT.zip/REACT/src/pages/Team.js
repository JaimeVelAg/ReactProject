import React from 'react'
import './styles/Team.css'
import CardTeam from '../components/CardTeam'

class Team extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      data: []
    }
  }

  async componentDidMount(){
    await this.fetchCards()
  }

  fetchCards = async () => {
    let res = await fetch('https://fitnesskingdommx.com/API/public/api/workers')
    let data = await res.json()

    this.setState({
      data
    })
  }

  render(){
    return (
      <div className="container">
      <h1 className="text-center">Conoce a nuestro equipo de trabajo</h1>
        <div className="row">
        {
          this.state.data.map((card) =>{
            return(
                <CardTeam
                    id={card.id}
                    name={card.name}
                    studies={card.studies}
                    others={card.others}
                />
            )
          })
        }
        </div>
      </div>
    )
  }
}

export default Team
