import React from 'react'
import logo from '../images/marca_agua.png'
import './styles/Navbar.css'
import { Link } from 'react-router-dom'

class Navbar extends React.Component {
  render(){
    return(
      <nav className="navbar navbar-expand-lg navbar-dark primary-color bg-primary text-light fixed-top barra">
        <Link className="navbar-brand" to="#">
        <img id="img" className="img" src={logo} />
        </Link>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item active">
              <Link className="nav-link" to="../">Inicio <span class="sr-only">(current)</span></Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="../testimonys/">Testimonios</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="../normas/">Normas de comunidad</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="../team/">Nuestro equipo</Link>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="../login/">Comunidad</a>
            </li>
          </ul>
        </div>
      </nav>
    )
  }
}

export default Navbar
