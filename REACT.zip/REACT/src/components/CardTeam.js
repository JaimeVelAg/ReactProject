import React from 'react'
import $ from 'jquery'
import './styles/CardTeam.css'

class CardTeam extends React.Component {
  constructor(props){
    super(props);
  }

  render(){
      return(
        <div class="col-xl-4 col-md-6 mb-4">
      <div class="card border-0 shadow">
        <img src={this.props.others} class="card-img-top imgbox" alt="..."/>
        <div class="card-body text-center">
          <h5 class="card-title mb-0">{this.props.name}</h5>
          <div class="card-text text-black-50">{this.props.studies}</div>
        </div>
      </div>
    </div>
      )
  }
}

export default CardTeam
