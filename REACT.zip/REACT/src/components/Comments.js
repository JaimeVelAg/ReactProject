import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrash, faEdit } from '@fortawesome/free-solid-svg-icons'
import './styles/Comments.css'
import { Link } from 'react-router-dom'
import Testimonystable from './Testimonystable'

class Comments extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      user : props.name,
      currentuser: props.currentuser    }
  }

  Issame = () => {
    let is = false;
    if (this.state.currentuser == this.state.user) {
      is = true;
    }else {
      is = false;
    }
    return is;
  }

  handledeleteComment = async e => {
    let id = this.props.id;
    e.preventDefault()
      try{
       let config = {
         method: 'DELETE'
       }
       let res = await fetch('https://fitnesskingdommx.com/API/public/api/comments/'+id+'', config);
       let json = await res.json();
       console.log(json);
       alert("Eliminado correctamente");
       window.location.replace("../login/");
     }catch (error){
       alert("No se pudo");
     }
  }



  render(){
    return (
      <div className="card">
          <div className="card-header">
              <div>{this.props.name}</div>
              <div>{this.Issame() ? <button onClick={this.handledeleteComment} className="btn btn-danger"><FontAwesomeIcon icon={ faTrash } /></button> : ''}</div>
          </div>
          <div className="card-body">
            <blockquote class="blockquote mb-0">
              <p>{this.props.text}</p>
              <footer className="blockquote-footer footerbox">
                  <div>{this.props.date}</div>
                  <div><Link to="/">Ver respuestas</Link></div>
              </footer>
            </blockquote>
          </div>
      </div>
    )
  }
}

export default Comments
