import React from 'react'
import './styles/CardPrising.css'


class CardPrising extends React.Component {
    constructor(props){
      super(props)
    }

    render(){
      return (
              <div className="card">
                <div className="card-header ">
                  <h4 className="font-weight-normal text-center" id="title-text">{this.props.title}</h4>
                </div>
                <div className="card-body">
                  <h1 className="card-title pricing-card-title">${this.props.price} <small class="text-muted">/ mo</small></h1>
                  <ul className="list-unstyled">
                    <li>-{this.props.description}</li>
                    <li>-{this.props.description2}</li>
                    <li>-{this.props.description3}</li>
                    <li>-{this.props.description4}</li>
                  </ul>
                  <button type="button" className="btn btn-lg btn-block btn-outline-primary">Contratar ahora</button>
                </div>
              </div>
      )
    }
}

export default CardPrising
