import React from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import Exercises from '../pages/Exercises'
import ExerciseNew from '../pages/ExerciseNew'
import Navbar from './Navbar'
import NotFound from '../pages/NotFound'
import Principal from '../pages/Principal'
import Login from '../pages/Login'
import Social_bar from '../components/Social_bar'
import Pie from '../components/Pie'
import Normas from '../pages/Normas'
import Team from '../pages/Team'


function App(){
    return (
      <BrowserRouter>
        <Navbar />
        <Social_bar />
        <Switch>
          <Route exact path="/" component={Principal} />
          <Route exact path="/testimonys/" component={Exercises} />
          <Route exact path="/exercises/new" component={ExerciseNew} />
          <Route exact path="/login/" component={Login} />
          <Route exact path="/normas/" component={Normas} />
          <Route exact path="/team/" component={Team} />
          <Route component={NotFound} />
        </Switch>
        <Pie />
      </BrowserRouter>
    )
}

export default App
