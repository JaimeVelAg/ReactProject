import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import './styles/Social_bar.css'
import { faTwitter, faFacebook } from '@fortawesome/free-brands-svg-icons'

class Social_bar extends React.Component {
    render(){
      return(
        <div className="social-bar">
          <a href="https://www.facebook.com/fitnessKingdomMX" className="icon icon-facebook" target="_blank"> <FontAwesomeIcon icon={ faFacebook } /> </a>
          <a href="https://twitter.com/JaimeVelagg" className="icon icon-twitter" target="_blank"> <FontAwesomeIcon icon={ faTwitter } /> </a>
        </div>
      )
    }
}
export default Social_bar
