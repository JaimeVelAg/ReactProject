import React from 'react'
import logo from '../images/marca_agua.png'
import './styles/Card.css'
import $ from 'jquery'

class Card extends React.Component {
  constructor(props){
    super(props);
  }

  changeMessage = () => {
    this.setState({message: "hello!!"});
  //  let id = this.attr('taskId');
  //  alert(id);
    var id = $('.id').val();
    alert(id);
}

  render() {
    return (
        <div className="Card-container" taskId={this.props.id}>
          <div>
            <img className="img" src={logo}/>
          </div>
          <div className="textos">
            <h1 className="title-exercise"> {this.props.message} </h1>
            <p className="description"> {this.props.paragraph} </p>
            <input onClick={this.changeMessage} className="btn btn-primary btn-go" type="text" name="" value="Go"></input>
            <input className="id" value={this.props.id} hidden></input>
          </div>
        </div>
    )
  }
}


export default Card
