import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrash, faEdit } from '@fortawesome/free-solid-svg-icons'
import Comments from './Comments'
import $ from 'jquery'
import './styles/Testimonystable.css'

class Testimonystable extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      data: []
       }
  }

  async componentDidMount(){
    await this.fetchCards()
  }

  fetchCards = async () => {
    let res = await fetch('https://fitnesskingdommx.com/API/public/api/comments')
    let data = await res.json()
    this.setState({
      data
    })
  }

handleshareComment = async e => {
  e.preventDefault()
  let text = $("#form-text2").val()
  let user = $("#user").val()
  let template = '';

  if(text.trim() == ''){
    $("#form-text2").focus();
    template += '<p> ingresa un mensaje </p>';
    $("#modal-footer").html(template);
  }else {
    var year = (new Date()).getFullYear();
    var month = (new Date()).getMonth();
    var day = (new Date()).getDate();

    month = month + 1;
    if (month < 10) {
      var hoy = year + "-0" + month + "-" +day;
    }else {
      var hoy = year + "-" + month + "-" +day;
    }

    let datos = {
      "name": user,
      "text": text,
      "fecha": hoy
    };

    try{
     let config = {
       method: 'POST',
       headers:{
         'Accept': 'application/json',
         'Content-Type': 'application/json'
       },
       body: JSON.stringify(datos)
     }

     let res = await fetch('https://fitnesskingdommx.com/API/public/api/comments', config);
     let json = await res.json();
     $("#form-text2").val('')
     $("#user").val('')
     $("#modal-footer").html(template);
     await this.fetchCards()
     alert("publicado correctamente")
   }catch (error){

   }
  }
}

  render(){
    return (
          <div className="container">
            <br/>
            <h4>Comentarios de la comunidad FK</h4>
            <button className="btn btn-success" data-toggle="modal" data-target="#modalRegisterForm">Agregar nuevo</button>
            {
              this.state.data.map((comment) =>{
                return (
                  <Comments
                      name={comment.name}
                      text={comment.text}
                      date={comment.fecha}
                      id={comment.id}
                      currentuser={this.props.usuario}
                  />
                )
              })
            }

            <div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
              <div className="modal-dialog" role="document">
                 <div className="modal-content">
                   <div className="modal-header text-center">
                     <h4 className="modal-title w-100 font-weight-bold">Escribe tu comentario</h4>
                     <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <div className="modal-body mx-3">
                     <div className="md-form mb-5">
                       <i className="fas fa-user prefix grey-text"></i>
                       <label className="label row" data-error="wrong" data-success="right" for="orangeForm-name">Texto</label>
                       <textarea className="text-input form-control z-depth-1" id="form-text2" />
                       <input id="user" type="text" value={this.props.usuario} hidden />
                     </div>
                     </div>
                     <div className="modal-footer d-flex justify-content-center">
                       <button onClick={this.handleshareComment} className="btn btn-success">Publicar</button>
                     </div>
                     <div id="modal-footer"></div>
                   </div>
                 </div>
               </div>
            </div>
    )
  }
}

export default Testimonystable
