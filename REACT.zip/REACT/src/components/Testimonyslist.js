import React from 'react'
import './styles/Testimonyslist.css'
import $ from 'jquery'
import gymsvg from '../images/gym.svg'
import logo from '../images/marca_agua.png'

class Testimonyslist extends React.Component {
  constructor(props){
    super(props);
  }

  render() {
    return (
          <div className="col-lg-4">
          <img className="bd-placeholder-img rounded-circle" width="140" height="140" src={gymsvg}/>
            <h2>{this.props.title}</h2>
            <h6 className="texto">{this.props.lugar}</h6>
            <p>{this.props.description}</p>
          </div>
    )
  }
}


export default Testimonyslist
