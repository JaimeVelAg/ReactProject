import React from 'react'
import './styles/Welcome.css'


function Welcome(props){
  return (
    <div className="header-text">
      <h3 className="title">Es muy importante saber en manos de quién pones tu salud</h3>
      <h6 className="title">Echa un vistazo a los testimonios de nuestros clientes</h6>
    </div>
  )
}

export default Welcome
