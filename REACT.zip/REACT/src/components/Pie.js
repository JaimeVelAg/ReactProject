import React from 'react'
import './styles/Pie.css'

class Pie extends React.Component {
  render(){
      return(
        <div class="pie primary-color bg-primary text-light">
          <footer>
              <div class="move-up">
                <span><i class="fas fa-arrow-circle-up fa-2x"></i></span>
              </div>

              <div class="about-us" data-aos="fade-right" data-aos-delay="200">
                <h2>Acerca de nosotros</h2>
                <p>Sitio web de salud y bienestar</p>
                <p>Nuestro objetivo es motivarte, retarte y hacer que pases un mejor día con notas informativas, memes, videos y recomendaciones.</p>
              </div>

              <div class="follow" data-aos="fade-left" data-aos-delay="200">
                <h2>Contáctanos</h2>
                <p>Para anuncios dentro de la página</p>
                  <div>
                    <p>jvelag28@gmail.com o facebook</p>
                  </div>
              </div>

              <div class="footer-copyright text-center py-3">
                Copyright ©2020 All rights reserved by FitnessKingdmMX
              </div>
            </footer>
        </div>
      )
  }
}

export default Pie
